<?php

namespace Illuminate\Contracts\Queue;

interface ShouldBeUnique
{
    //
}
